plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val globalAssetRegistryUrl = providers.gradleProperty("GLOBAL_ASSET_REGISTRY_URL").orElse("").get()

android {
    namespace = "com.hamrahsarmaye.app"
    compileSdk = 35

    buildFeatures { buildConfig = true }
    defaultConfig {
        buildConfigField("String", "GLOBAL_ASSET_REGISTRY_URL", "\"${globalAssetRegistryUrl}\"")
        applicationId = "com.hamrahsarmaye.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 16
        versionName = "0.4.0-dev"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
