package com.hamrahsarmaye.app

/**
 * Maker-owned global market catalog. It is deliberately independent from a user's holdings.
 * A catalog entry is a market reference, not a recommendation or a claim that a live feed exists.
 */
data class GlobalCatalogEntry(
    val key: String,
    val title: String,
    val assetType: String,
    val assetName: String,
    val benchmarkId: String,
    val unit: String,
    val description: String
)

data class AssetCategory(
    val key: String,
    val title: String,
    val icon: String,
    val assetType: String,
    val description: String
)

object GlobalAssetCatalog {
    /** Main dashboard groups. Brands, vehicle models and property types are user-selected inside each group. */
    val categories = listOf(
        AssetCategory("gold", "طلا", "🥇", "طلا و فلزات", "طلای ۱۸ عیار، آب‌شده، مثقال، سکه و اونس"),
        AssetCategory("silver", "نقره", "🪙", "طلا و فلزات", "نقره با عیار و وزن مشخص"),
        AssetCategory("fx", "ارز", "💱", "ارز", "دلار، یورو و ارزهای قابل انتخاب"),
        AssetCategory("vehicle", "خودرو", "🚗", "خودرو", "انتخاب آزاد سازنده، مدل، تیپ، سال و کارکرد"),
        AssetCategory("property", "ملک", "🏠", "خانه / ملک", "انتخاب نوع ملک، کشور، شهر، منطقه و مشخصات"),
        AssetCategory("energy", "نفت و کالا", "🛢️", "نفت و کالا", "نفت و کالاهای منتخب با مرجع تخصصی")
    )

    /**
     * Global reference feeds are loaded for every user, whether or not they own these assets.
     * Vehicle and property do not have one universal world price; they require comparable model- or
     * location-specific datasets and therefore must not be assigned a fabricated generic quote.
     */
    val globalReferences = listOf(
        GlobalCatalogEntry("gold.spot", "اونس جهانی طلا", "طلا و فلزات", "اونس جهانی طلا", "XAUUSD", "troy_ounce", "قیمت نقدی جهانی طلا به دلار برای هر اونس تروا"),
        GlobalCatalogEntry("silver.spot", "اونس جهانی نقره", "طلا و فلزات", "اونس جهانی نقره", "XAGUSD", "troy_ounce", "قیمت جهانی نقره به دلار برای هر اونس تروا"),
        GlobalCatalogEntry("fx.eurusd", "جفت‌ارز EUR/USD", "ارز", "EUR/USD", "EURUSD", "currency_pair", "نرخ مرجع جهانی یورو در برابر دلار"),
        GlobalCatalogEntry("energy.brent", "نفت برنت", "نفت و کالا", "نفت برنت", "BRENT", "barrel", "شاخص جهانی نفت برنت به دلار برای هر بشکه"),
        GlobalCatalogEntry("energy.wti", "نفت WTI", "نفت و کالا", "نفت WTI", "WTI", "barrel", "شاخص جهانی نفت WTI به دلار برای هر بشکه")
    )

    fun referenceByKey(key: String): GlobalCatalogEntry? = globalReferences.firstOrNull { it.key == key }
}
