/**
 * Secure provider proxy for Hamrah Sarmaye.
 * Configure only from the provider's current official API documentation:
 *   TALASANJ_KEY (Worker Secret)
 *   TALASANJ_API_URL (Worker Variable; exact documented endpoint)
 *   TALASANJ_AUTH_HEADER (Worker Variable; e.g. documented header name)
 *   TALASANJ_AUTH_PREFIX (Worker Variable; exact documented prefix, may be empty)
 * Never commit API keys or guess provider endpoints/authentication formats.
 */
export default {
  async fetch(request, env) {
    const allowedOrigin = env.APP_ORIGIN || '*';
    const origin = request.headers.get('Origin');
    const cors = {
      'Access-Control-Allow-Origin': allowedOrigin,
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-API-Key',
      'Vary': 'Origin'
    };

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (allowedOrigin !== '*' && origin && origin !== allowedOrigin) {
      return new Response('Origin not allowed', { status: 403, headers: cors });
    }
    if (request.method !== 'GET') return new Response('Method Not Allowed', { status: 405, headers: cors });

    const url = new URL(request.url);
    if (url.pathname === '/health') {
      return Response.json({
        ok: true,
        provider: 'Talasanj',
        configured: Boolean(env.TALASANJ_KEY && env.TALASANJ_API_URL && env.TALASANJ_AUTH_HEADER)
      }, { headers: cors });
    }
    if (url.pathname !== '/api/prices') return new Response('Not Found', { status: 404, headers: cors });
    if (!env.TALASANJ_KEY || !env.TALASANJ_API_URL || !env.TALASANJ_AUTH_HEADER) {
      return new Response('Provider endpoint/auth configuration is incomplete; use official API documentation.', { status: 503, headers: cors });
    }

    let upstreamUrl;
    try {
      upstreamUrl = new URL(env.TALASANJ_API_URL);
      if (upstreamUrl.protocol !== 'https:') throw new Error('HTTPS required');
    } catch (_) {
      return new Response('Invalid provider endpoint configuration', { status: 503, headers: cors });
    }

    try {
      const headers = new Headers({ 'Accept': 'application/json' });
      const prefix = env.TALASANJ_AUTH_PREFIX || '';
      headers.set(env.TALASANJ_AUTH_HEADER, `${prefix}${env.TALASANJ_KEY}`);
      const upstream = await fetch(upstreamUrl.toString(), {
        method: 'GET', headers, signal: AbortSignal.timeout(12000)
      });
      const body = await upstream.arrayBuffer();
      if (body.byteLength > 1_000_000) return new Response('Provider response too large', { status: 502, headers: cors });
      const responseHeaders = new Headers(cors);
      responseHeaders.set('Content-Type', upstream.headers.get('Content-Type') || 'application/json; charset=utf-8');
      responseHeaders.set('Cache-Control', 'no-store');
      responseHeaders.set('X-Price-Provider', 'Talasanj');
      return new Response(body, { status: upstream.status, headers: responseHeaders });
    } catch (_) {
      return new Response('Provider request failed or timed out', { status: 502, headers: cors });
    }
  }
};
