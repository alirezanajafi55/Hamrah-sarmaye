/**
 * Secure Talasanj proxy for Hamrah Sarmaye.
 * Configure TALASANJ_KEY as a Cloudflare Worker Secret; never commit the value.
 * Optional vars: APP_ORIGIN (exact app web origin, or '*' only for a private test).
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method !== 'GET') return new Response('Method Not Allowed', { status: 405 });

    const allowedOrigin = env.APP_ORIGIN || '*';
    const origin = request.headers.get('Origin');
    if (allowedOrigin !== '*' && origin && origin !== allowedOrigin) {
      return new Response('Origin not allowed', { status: 403 });
    }

    const cors = {
      'Access-Control-Allow-Origin': allowedOrigin,
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Vary': 'Origin'
    };

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (url.pathname === '/health') {
      return Response.json({ ok: true, provider: 'Talasanj', configured: Boolean(env.TALASANJ_KEY) }, { headers: cors });
    }
    if (url.pathname !== '/api/prices') return new Response('Not Found', { status: 404 });
    if (!env.TALASANJ_KEY) return new Response('Provider secret is not configured', { status: 503, headers: cors });

    const upstream = await fetch('https://talasanj.info/api/v1/prices', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${env.TALASANJ_KEY}`,
        'X-Client-Name': 'Hamrah Sarmaye',
        'X-Client-Url': url.origin
      }
    });
    const body = await upstream.arrayBuffer();
    const headers = new Headers(cors);
    headers.set('Content-Type', upstream.headers.get('Content-Type') || 'application/json; charset=utf-8');
    headers.set('Cache-Control', 'no-store');
    headers.set('X-Price-Provider', 'Talasanj');
    return new Response(body, { status: upstream.status, headers });
  }
};
