package com.hamrahsarmaye.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Configurable JSON HTTP feed. No provider is considered active until its endpoint and JSON path are verified. */
data class MarketFeedConfig(
    val id: String,
    val endpoint: String,
    val valuePath: String,
    val timestampPath: String? = null,
    val currency: String,
    val unit: String,
    val providerName: String,
    val assetKey: String,
    val market: QuoteMarket,
    val countryCode: String? = null,
    val staticHeaders: Map<String, String> = emptyMap(),
    val maxAgeMs: Long = 5 * 60_000L
)

sealed class FeedResult {
    data class Success(val quote: MarketQuote) : FeedResult()
    data class Failure(val reason: String) : FeedResult()
}

object MarketFeedClient {
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 10_000

    fun fetch(config: MarketFeedConfig, nowMs: Long = System.currentTimeMillis()): FeedResult {
        if (!config.endpoint.startsWith("https://", true)) return FeedResult.Failure("Only HTTPS feed endpoints are accepted")
        if (config.valuePath.isBlank() || config.timestampPath.isNullOrBlank() || config.currency.isBlank() || config.unit.isBlank() || config.providerName.isBlank())
            return FeedResult.Failure("Incomplete feed configuration: price and source timestamp paths are required")
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(config.endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
                config.staticHeaders.forEach { (key, value) -> setRequestProperty(key, value) }
            }
            if (connection.responseCode !in 200..299) return FeedResult.Failure("HTTP ${connection.responseCode}")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (body.length > 1_000_000) return FeedResult.Failure("Feed response too large")
            val json = JSONObject(body)
            val value = readPath(json, config.valuePath)?.toString()?.replace(',', '.')?.toDoubleOrNull()
                ?: return FeedResult.Failure("Price field not found or not numeric")
            val observedAt = readTimestamp(readPath(json, config.timestampPath))
            if (!value.isFinite() || value <= 0.0) return FeedResult.Failure("Price must be a positive finite number")
            if (observedAt <= 0L || observedAt > nowMs) return FeedResult.Failure("Invalid observation timestamp")
            val age = nowMs - observedAt
            val status = if (age > config.maxAgeMs) QuoteStatus.STALE else QuoteStatus.LIVE
            FeedResult.Success(MarketQuote(
                value = value, currency = config.currency.uppercase(), unit = config.unit,
                provider = config.providerName, observedAtEpochMs = observedAt,
                receivedAtEpochMs = nowMs, status = status, market = config.market,
                countryCode = config.countryCode, assetKey = config.assetKey
            ))
        } catch (e: Exception) {
            FeedResult.Failure(e.message ?: e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    private fun readPath(root: JSONObject, path: String): Any? {
        var current: Any? = root
        for (part in path.split('.')) {
            current = when (current) {
                is JSONObject -> if (current.has(part)) current.opt(part) else null
                else -> null
            }
            if (current == null || current == JSONObject.NULL) return null
        }
        return current
    }

    /** Accepts epoch seconds/milliseconds and ISO-8601 timestamps (e.g. Talasanj updated_at). */
    private fun readTimestamp(raw: Any?): Long {
        val value = raw?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: return -1L
        val numeric = value.toLongOrNull()
        if (numeric != null) return if (numeric in 1..9_999_999_999L) numeric * 1000L else numeric

        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            "yyyy-MM-dd'T'HH:mm:ssX",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'"
        )
        for (pattern in patterns) {
            try {
                val parser = SimpleDateFormat(pattern, Locale.US).apply {
                    isLenient = false
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val parsed = parser.parse(value)?.time
                if (parsed != null && parsed > 0L) return parsed
            } catch (_: Exception) { /* Try the next strict ISO-8601 shape. */ }
        }
        return -1L
    }
}

/** Runs configured feeds independently. Call stop() from Activity.onDestroy(). */
class MarketRefreshScheduler(
    private val intervalMs: Long = 5 * 60_000L,
    private val onResult: (MarketFeedConfig, FeedResult) -> Unit
) {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var started = false

    fun start(configs: List<MarketFeedConfig>) {
        if (started || configs.isEmpty()) return
        started = true
        executor.scheduleWithFixedDelay({
            configs.forEach { config ->
                val result = MarketFeedClient.fetch(config)
                onResult(config, result)
            }
        }, 0, intervalMs, TimeUnit.MILLISECONDS)
    }

    fun stop() {
        started = false
        executor.shutdownNow()
    }
}
