package com.hamrahsarmaye.app

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Update manifest JSON contract:
 * { "versionCode": 5, "versionName": "0.2.3", "releaseNotes": "...", "apkUrl": "https://.../app-release.apk" }
 * The manifest URL must be configured by the project owner before this feature can be used.
 */
object UpdateSupport {
    // Replace with the HTTPS URL of the maker-controlled update.json before publishing.
    const val UPDATE_MANIFEST_URL = ""

    fun check(activity: Activity, onResult: (JSONObject?, String?) -> Unit) {
        if (UPDATE_MANIFEST_URL.isBlank()) {
            onResult(null, "نشانی سرور به‌روزرسانی هنوز توسط سازنده تنظیم نشده است.")
            return
        }
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(UPDATE_MANIFEST_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000
                    readTimeout = 10000
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/json")
                }
                if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val manifest = JSONObject(body)
                val versionCode = manifest.optInt("versionCode", -1)
                val versionName = manifest.optString("versionName", "")
                val apkUrl = manifest.optString("apkUrl", "")
                if (versionCode < 1 || versionName.isBlank() || !apkUrl.startsWith("https://")) {
                    throw IllegalArgumentException("ساختار فایل اطلاعات نسخه معتبر نیست.")
                }
                Handler(Looper.getMainLooper()).post { onResult(manifest, null) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { onResult(null, e.message ?: "خطا در بررسی نسخه") }
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    fun downloadAndInstall(activity: Activity, apkUrl: String, versionName: String) {
        try {
            require(apkUrl.startsWith("https://")) { "فقط نشانی امن HTTPS مجاز است." }
            val request = DownloadManager.Request(Uri.parse(apkUrl))
                .setTitle("همراه سرمایه $versionName")
                .setDescription("دریافت نسخه جدید همراه سرمایه")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, "hamrah-sarmaye-$versionName.apk")
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(activity, "دریافت آغاز شد؛ پس از پایان، اعلان دانلود را باز و نصب را تأیید کنید.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            AlertDialog.Builder(activity).setMessage("شروع دریافت ممکن نشد: ${e.message}")
                .setPositiveButton("باشه", null).show()
        }
    }
}
