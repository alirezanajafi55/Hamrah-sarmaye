# اصلاح لوگوها و ساخت APK

- آیکون لانچر: `Polish_۲۰۲۶۱۱۲۶_۱۳۲۳۴۹۳۵۷.jpg`
- لوگوی داخل برنامه: `Logopit_1795673552004.jpg`
- `MainActivity` از قبل `R.drawable.app_logo` را برای لوگوی داخل برنامه می‌خواند؛ Workflow تصویر جدید را دقیقاً در همان منبع قرار می‌دهد.
- Workflow فایل‌های adaptive icon و آیکون‌های قدیمی را با منابع جدید جایگزین می‌کند و Manifest را روی `@mipmap/ic_launcher` و `@mipmap/ic_launcher_round` تنظیم می‌کند.
- نصب SDK از ورودی چندخطی مشکل‌دار به اجرای مستقیم `sdkmanager --install` تغییر داده شده است.

برای اجرای Workflow، هر دو تصویر تأییدشده باید در ریشه مخزن GitHub کنار ZIP سورس باشند.
