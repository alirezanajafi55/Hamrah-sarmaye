/**
 * Secure market-data gateway for Hamrah Sarmaye.
 *
 * Worker Variables (non-secret configuration):
 *   APP_ORIGIN                    optional app/web origin, default '*'
 *   GLOBAL_ASSET_REGISTRY_JSON    JSON registry returned by /registry
 *   GLOBAL_FEEDS_JSON             JSON object mapping assetKey -> providers[]
 *
 * Worker Secrets (one per licensed data vendor):
 *   e.g. GLOBAL_GOLD_VENDOR_KEY, GLOBAL_SILVER_VENDOR_KEY, TALASANJ_KEY
 *
 * GLOBAL_FEEDS_JSON provider example:
 * {
 *   "gold.spot": {"providers":[{
 *     "id":"primary", "url":"https://licensed-vendor.example/api/gold",
 *     "allowedHosts":["licensed-vendor.example"],
 *     "secretName":"GLOBAL_GOLD_VENDOR_KEY",
 *     "authHeader":"Authorization", "authPrefix":"Bearer ",
 *     "headers":{"Accept":"application/json"}
 *   }]}
 * }
 *
 * Never put credentials in the APK, registry JSON, or public Git repository.
 * Use only feeds licensed for the intended display/redistribution and derived-data use.
 */
export default {
  async fetch(request, env) {
    const allowedOrigin = env.APP_ORIGIN || '*';
    const origin = request.headers.get('Origin');
    const cors = {
      'Access-Control-Allow-Origin': allowedOrigin,
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Vary': 'Origin'
    };
    const json = (value, status = 200, extra = {}) => Response.json(value, {
      status, headers: { ...cors, 'Cache-Control': 'no-store', ...extra }
    });

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (allowedOrigin !== '*' && origin && origin !== allowedOrigin) {
      return new Response('Origin not allowed', { status: 403, headers: cors });
    }
    if (request.method !== 'GET') return new Response('Method Not Allowed', { status: 405, headers: cors });

    const url = new URL(request.url);
    if (url.pathname === '/health') {
      return json({
        ok: true,
        registryConfigured: Boolean(env.GLOBAL_ASSET_REGISTRY_JSON),
        globalFeedsConfigured: Boolean(env.GLOBAL_FEEDS_JSON),
        domesticTalasanjConfigured: Boolean(env.TALASANJ_KEY && env.TALASANJ_API_URL && env.TALASANJ_AUTH_HEADER)
      });
    }

    if (url.pathname === '/registry') {
      if (!env.GLOBAL_ASSET_REGISTRY_JSON) return json({ error: 'Global registry is not configured' }, 503);
      try {
        const registry = JSON.parse(env.GLOBAL_ASSET_REGISTRY_JSON);
        if (!registry || !Array.isArray(registry.assets)) return json({ error: 'Invalid registry schema' }, 503);
        return json(registry, 200, { 'Cache-Control': 'public, max-age=300' });
      } catch (_) {
        return json({ error: 'Registry JSON is invalid' }, 503);
      }
    }

    const globalMatch = url.pathname.match(/^\/api\/global\/([a-z0-9._-]+)\/([a-z0-9_-]+)$/i);
    if (globalMatch) {
      if (!env.GLOBAL_FEEDS_JSON) return json({ error: 'Global provider routes are not configured' }, 503);
      let allFeeds;
      try { allFeeds = JSON.parse(env.GLOBAL_FEEDS_JSON); }
      catch (_) { return json({ error: 'Global feed configuration is invalid' }, 503); }

      const [, assetKey, routeId] = globalMatch;
      const routes = allFeeds?.[assetKey]?.providers;
      const route = Array.isArray(routes) ? routes.find(p => p.id === routeId) : null;
      if (!route || typeof route.url !== 'string') return json({ error: 'Provider route not found' }, 404);

      let upstreamUrl;
      try {
        upstreamUrl = new URL(route.url);
        if (upstreamUrl.protocol !== 'https:') throw new Error('HTTPS required');
        const allowedHosts = Array.isArray(route.allowedHosts) ? route.allowedHosts : [];
        if (!allowedHosts.includes(upstreamUrl.hostname)) throw new Error('Upstream host is not allow-listed');
      } catch (error) {
        return json({ error: error.message || 'Invalid upstream configuration' }, 503);
      }

      try {
        const headers = new Headers({ Accept: 'application/json' });
        if (route.headers && typeof route.headers === 'object') {
          for (const [key, value] of Object.entries(route.headers)) {
            if (typeof value === 'string' && !/authorization|api[-_]key|token/i.test(key)) headers.set(key, value);
          }
        }
        if (route.secretName) {
          const secret = env[route.secretName];
          if (!secret || !route.authHeader) return json({ error: 'Provider secret is not configured' }, 503);
          headers.set(route.authHeader, `${route.authPrefix || ''}${secret}`);
        }
        const upstream = await fetch(upstreamUrl.toString(), {
          method: 'GET', headers, signal: AbortSignal.timeout(12000)
        });
        const body = await upstream.arrayBuffer();
        if (body.byteLength > 1_000_000) return json({ error: 'Provider response too large' }, 502);
        const responseHeaders = new Headers(cors);
        responseHeaders.set('Content-Type', upstream.headers.get('Content-Type') || 'application/json; charset=utf-8');
        responseHeaders.set('Cache-Control', 'no-store');
        responseHeaders.set('X-Price-Provider', String(route.providerName || 'licensed provider'));
        return new Response(body, { status: upstream.status, headers: responseHeaders });
      } catch (_) {
        return json({ error: 'Provider request failed or timed out' }, 502);
      }
    }

    // Domestic Talasanj route retained for compatibility; configure only from its official API docs.
    if (url.pathname === '/api/prices') {
      if (!env.TALASANJ_KEY || !env.TALASANJ_API_URL || !env.TALASANJ_AUTH_HEADER) {
        return json({ error: 'Talasanj endpoint/auth configuration is incomplete' }, 503);
      }
      let upstreamUrl;
      try {
        upstreamUrl = new URL(env.TALASANJ_API_URL);
        if (upstreamUrl.protocol !== 'https:') throw new Error('HTTPS required');
      } catch (_) { return json({ error: 'Invalid Talasanj endpoint configuration' }, 503); }
      try {
        const headers = new Headers({ Accept: 'application/json' });
        headers.set(env.TALASANJ_AUTH_HEADER, `${env.TALASANJ_AUTH_PREFIX || ''}${env.TALASANJ_KEY}`);
        const upstream = await fetch(upstreamUrl.toString(), {
          method: 'GET', headers, signal: AbortSignal.timeout(12000)
        });
        const body = await upstream.arrayBuffer();
        if (body.byteLength > 1_000_000) return json({ error: 'Talasanj response too large' }, 502);
        const responseHeaders = new Headers(cors);
        responseHeaders.set('Content-Type', upstream.headers.get('Content-Type') || 'application/json; charset=utf-8');
        responseHeaders.set('Cache-Control', 'no-store');
        responseHeaders.set('X-Price-Provider', 'Talasanj');
        return new Response(body, { status: upstream.status, headers: responseHeaders });
      } catch (_) { return json({ error: 'Talasanj request failed or timed out' }, 502); }
    }

    return new Response('Not Found', { status: 404, headers: cors });
  }
};
