package com.hamrahsarmaye.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** A configured provider route. The endpoint must be the maker's HTTPS proxy or a licensed public feed. */
data class MarketFeedConfig(
    val id: String,
    val endpoint: String,
    val valuePath: String,
    val timestampPath: String? = null,
    val currency: String,
    val unit: String,
    val providerName: String,
    val assetKey: String,
    val market: QuoteMarket,
    val countryCode: String? = null,
    val staticHeaders: Map<String, String> = emptyMap(),
    val maxAgeMs: Long = 5 * 60_000L,
    val marketName: String = "",
    val providerStatus: QuoteStatus = QuoteStatus.LIVE,
    val fallbacks: List<GlobalFeedSource> = emptyList()
)

sealed class FeedResult {
    data class Success(val quote: MarketQuote) : FeedResult()
    data class Failure(val reason: String) : FeedResult()
}

object MarketFeedClient {
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 10_000
    private const val MAX_RESPONSE_CHARS = 1_000_000

    /** Try the primary provider first, then configured fallback providers in order. */
    fun fetch(config: MarketFeedConfig, nowMs: Long = System.currentTimeMillis()): FeedResult {
        val primary = fetchOne(
            endpoint = config.endpoint, valuePath = config.valuePath, timestampPath = config.timestampPath,
            currency = config.currency, unit = config.unit, provider = config.providerName,
            marketName = config.marketName, providerStatus = config.providerStatus, headers = config.staticHeaders,
            maxAgeMs = config.maxAgeMs, config = config, nowMs = nowMs
        )
        if (primary is FeedResult.Success && MarketDataPolicy.assess(primary.quote, nowMs, config.maxAgeMs).usableForAnalysis) return primary

        val failures = mutableListOf(if (primary is FeedResult.Failure) primary.reason else "Primary quote is stale or invalid")
        for (fallback in config.fallbacks) {
            val result = fetchOne(
                endpoint = fallback.endpoint, valuePath = fallback.valuePath, timestampPath = fallback.timestampPath,
                currency = fallback.currency, unit = fallback.unit, provider = fallback.providerName,
                marketName = fallback.marketName, providerStatus = fallback.status, headers = emptyMap(), maxAgeMs = config.maxAgeMs,
                config = config, nowMs = nowMs
            )
            if (result is FeedResult.Success && MarketDataPolicy.assess(result.quote, nowMs, config.maxAgeMs).usableForAnalysis) return result
            failures += if (result is FeedResult.Failure) "${fallback.providerName}: ${result.reason}" else "${fallback.providerName}: stale/invalid quote"
        }
        return FeedResult.Failure("همه مسیرهای دریافت قیمت ناموفق یا قدیمی بودند: ${failures.joinToString(" | ")}")
    }

    private fun fetchOne(
        endpoint: String, valuePath: String, timestampPath: String?, currency: String, unit: String,
        provider: String, marketName: String, providerStatus: QuoteStatus, headers: Map<String, String>, maxAgeMs: Long,
        config: MarketFeedConfig, nowMs: Long
    ): FeedResult {
        if (!endpoint.startsWith("https://", true)) return FeedResult.Failure("Only HTTPS feed endpoints are accepted")
        if (valuePath.isBlank() || timestampPath.isNullOrBlank() || currency.isBlank() || unit.isBlank() || provider.isBlank())
            return FeedResult.Failure("Incomplete feed configuration: price and source timestamp paths are required")
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
                headers.forEach { (key, value) -> setRequestProperty(key, value) }
            }
            if (connection.responseCode !in 200..299) return FeedResult.Failure("HTTP ${connection.responseCode}")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (body.length > MAX_RESPONSE_CHARS) return FeedResult.Failure("Feed response too large")
            val json = JSONObject(body)
            val value = readPath(json, valuePath)?.toString()?.replace(',', '.')?.toDoubleOrNull()
                ?: return FeedResult.Failure("Price field not found or not numeric")
            val observedAt = readTimestamp(readPath(json, timestampPath))
            if (!value.isFinite() || value <= 0.0) return FeedResult.Failure("Price must be a positive finite number")
            if (observedAt <= 0L || observedAt > nowMs) return FeedResult.Failure("Invalid observation timestamp")
            val age = nowMs - observedAt
            val status = if (age > maxAgeMs) QuoteStatus.STALE else providerStatus
            FeedResult.Success(MarketQuote(
                value = value, currency = currency.uppercase(Locale.ROOT), unit = unit,
                provider = provider, observedAtEpochMs = observedAt,
                receivedAtEpochMs = nowMs, status = status, market = config.market,
                countryCode = config.countryCode, assetKey = config.assetKey,
                marketName = marketName
            ))
        } catch (e: Exception) {
            FeedResult.Failure(e.message ?: e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    private fun readPath(root: JSONObject, path: String): Any? {
        var current: Any? = root
        for (part in path.split('.')) {
            current = when (current) {
                is JSONObject -> if (current.has(part)) current.opt(part) else null
                else -> null
            }
            if (current == null || current == JSONObject.NULL) return null
        }
        return current
    }

    /** Accept epoch seconds/milliseconds and ISO-8601 timestamps. */
    private fun readTimestamp(raw: Any?): Long {
        val value = raw?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: return -1L
        val numeric = value.toLongOrNull()
        if (numeric != null) return if (numeric in 1..9_999_999_999L) numeric * 1000L else numeric
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"
        )
        for (pattern in patterns) try {
            val parser = SimpleDateFormat(pattern, Locale.US).apply {
                isLenient = false
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val parsed = parser.parse(value)?.time
            if (parsed != null && parsed > 0L) return parsed
        } catch (_: Exception) { }
        return -1L
    }
}

/** Runs configured feeds independently. Call stop() from Activity.onDestroy(). */
class MarketRefreshScheduler(
    private val intervalMs: Long = 5 * 60_000L,
    private val onResult: (MarketFeedConfig, FeedResult) -> Unit
) {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var started = false

    fun start(configs: List<MarketFeedConfig>) {
        if (started || configs.isEmpty()) return
        started = true
        executor.scheduleWithFixedDelay({
            configs.forEach { config ->
                val result = MarketFeedClient.fetch(config)
                onResult(config, result)
            }
        }, 0, intervalMs, TimeUnit.MILLISECONDS)
    }

    fun stop() {
        started = false
        executor.shutdownNow()
    }
}
