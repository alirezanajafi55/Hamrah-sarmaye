package com.hamrahsarmaye.app

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/** Historical domestic 18k price observation. Prices must use one currency and one unit. */
data class GoldPriceBar(val observedAtEpochMs: Long, val close: Double)

data class GoldCalibration(
    /** Number of out-of-sample historical signals evaluated for this horizon and signal family. */
    val sampleCount: Int,
    /** Empirical fraction of evaluated signals that reached the defined target before stop. */
    val targetBeforeStopRate: Double,
    /** Brier score of the historical probability forecasts, 0 is best. */
    val brierScore: Double
)

enum class GoldAction { BUY, SELL, WAIT, NO_SIGNAL }
enum class GoldConfidence { LOW, MEDIUM, HIGH, UNAVAILABLE }

data class GoldAnalysisInput(
    val nowEpochMs: Long,
    val spotUsdPerTroyOunce: Double,
    val usdToLocal: Double,
    val domestic18kPerGram: Double,
    val mesghal17kPrice: Double? = null,
    val coinMarketPrice: Double? = null,
    val coinFineGoldGrams: Double? = null,
    val quoteAgeMs: Long,
    val history: List<GoldPriceBar>,
    val calibration: GoldCalibration? = null,
    val forecastHorizonHours: Int = 24
)

data class GoldAnalysisOutput(
    val action: GoldAction,
    val confidence: GoldConfidence,
    val theoretical18kPerGram: Double?,
    val mesghalDerived18kPerGram: Double?,
    val domesticPremiumPercent: Double?,
    val coinPremiumPercent: Double?,
    val expectedReturnPercent: Double?,
    val probabilityTargetBeforeStopPercent: Double?,
    val estimatedProfitPercent: Double?,
    val estimatedLossPercent: Double?,
    val entryFromEpochMs: Long?,
    val entryUntilEpochMs: Long?,
    val exitFromEpochMs: Long?,
    val exitUntilEpochMs: Long?,
    val stopPrice: Double?,
    val targetPrice: Double?,
    val reason: String
)

/**
 * Private-rule engine for Iranian gold. It never fabricates a signal when fresh quotes,
 * sufficient history, or out-of-sample calibration are missing.
 * All quote values must already be normalized to the same local currency (e.g. toman).
 */
object GoldAnalysisEngine {
    private const val MESGHAL_GRAMS = 4.608
    private const val MESGHAL_PURITY = 705.0
    private const val GOLD18_PURITY = 750.0
    private const val MIN_HISTORY = 48
    private const val MAX_QUOTE_AGE_MS = 5 * 60_000L
    private const val MIN_CALIBRATION_SAMPLES = 100
    private const val MAX_ACCEPTABLE_BRIER = 0.25

    fun analyze(input: GoldAnalysisInput): GoldAnalysisOutput {
        val theoretical = AssetValuationCore.gold18Gram(input.spotUsdPerTroyOunce, input.usdToLocal).theoreticalLocalValue
        val mesghalDerived = input.mesghal17kPrice?.takeIf { it.isFinite() && it > 0.0 }
            ?.let { it / MESGHAL_GRAMS * GOLD18_PURITY / MESGHAL_PURITY }
        val premium = if (input.domestic18kPerGram > 0.0 && theoretical != null)
            ((input.domestic18kPerGram / theoretical) - 1.0) * 100.0 else null
        val coinPremium = if (input.coinMarketPrice != null && input.coinFineGoldGrams != null &&
            input.coinMarketPrice.isFinite() && input.coinMarketPrice > 0.0 &&
            input.coinFineGoldGrams.isFinite() && input.coinFineGoldGrams > 0.0 && theoretical != null) {
            val intrinsic = theoretical * input.coinFineGoldGrams / GOLD18_PURITY
            if (intrinsic > 0.0) (input.coinMarketPrice / intrinsic - 1.0) * 100.0 else null
        } else null

        fun unavailable(reason: String) = GoldAnalysisOutput(
            GoldAction.WAIT, GoldConfidence.UNAVAILABLE, theoretical, mesghalDerived, premium,
            coinPremium, null, null, null, null, null, null, null, null, null, null, reason
        )

        if (input.quoteAgeMs !in 0..MAX_QUOTE_AGE_MS)
            return unavailable("داده قیمت تازه و قابل اتکا نیست؛ فعلاً سیگنال صادر نمی‌شود.")
        if (theoretical == null || input.domestic18kPerGram <= 0.0 || !input.domestic18kPerGram.isFinite())
            return unavailable("ورودی‌های معتبر اونس، نرخ ارز و قیمت داخلی کامل نیستند.")
        if (mesghalDerived != null && abs(mesghalDerived / input.domestic18kPerGram - 1.0) > 0.035)
            return unavailable("اختلاف مظنه و قیمت داخلی از حد کنترل کیفیت بیشتر است؛ داده‌ها باید بررسی شوند.")
        if (input.history.size < MIN_HISTORY)
            return unavailable("برای پیش‌بینی معتبر، تاریخچه کافی از قیمت داخلی در دسترس نیست.")
        if (input.forecastHorizonHours !in 1..48)
            return unavailable("افق پیش‌بینی خارج از محدوده مجاز موتور است.")

        val bars = input.history.filter { it.close.isFinite() && it.close > 0.0 && it.observedAtEpochMs > 0L }
            .sortedBy { it.observedAtEpochMs }.takeLast(240)
        if (bars.size < MIN_HISTORY || bars.zipWithNext().any { (a, b) -> b.observedAtEpochMs <= a.observedAtEpochMs })
            return unavailable("تاریخچه قیمت ناقص یا دارای زمان‌بندی نامعتبر است.")
        val last = bars.last()
        if (input.nowEpochMs - last.observedAtEpochMs !in 0..MAX_QUOTE_AGE_MS)
            return unavailable("آخرین داده تاریخی تازه نیست.")

        val returns = bars.zipWithNext().map { (a, b) -> ln(b.close / a.close) }
        if (returns.size < MIN_HISTORY - 1) return unavailable("نمونه‌های تاریخی کافی نیستند.")
        val mean = returns.average()
        val variance = returns.sumOf { (it - mean) * (it - mean) } / (returns.size - 1).coerceAtLeast(1)
        val sigma = sqrt(variance).takeIf { it.isFinite() && it > 0.0 }
            ?: return unavailable("نوسان تاریخی قابل محاسبه نیست.")

        // Recent trend is damped to avoid extrapolating a short-lived spike indefinitely.
        val recent = returns.takeLast(12)
        val recentMean = recent.average()
        val drift = (recentMean * 0.35 + mean * 0.65).coerceIn(-sigma * 1.5, sigma * 1.5)
        val horizonBars = input.forecastHorizonHours.coerceAtLeast(1)
        val expectedReturn = (drift * horizonBars).coerceIn(-0.12, 0.12) * 100.0
        val horizonVol = sigma * sqrt(horizonBars.toDouble())
        val stopDistance = (1.5 * horizonVol).coerceIn(0.003, 0.08)
        val targetDistance = (2.0 * horizonVol).coerceIn(0.004, 0.12)
        val calibration = input.calibration
        val calibrated = calibration != null && calibration.sampleCount >= MIN_CALIBRATION_SAMPLES &&
            calibration.targetBeforeStopRate in 0.0..1.0 && calibration.brierScore in 0.0..MAX_ACCEPTABLE_BRIER

        if (!calibrated) {
            return GoldAnalysisOutput(
                GoldAction.WAIT, GoldConfidence.LOW, theoretical, mesghalDerived, premium, coinPremium,
                expectedReturn, null, null, null, null, null, null, null, null, null,
                "مدل روند را محاسبه کرده، اما هنوز ارزیابی تاریخی خارج از نمونه کافی برای اعلام احتمال موفقیت ندارد؛ سیگنال معاملاتی صادر نمی‌شود."
            )
        }

        val probability = calibration!!.targetBeforeStopRate * 100.0
        val premiumPenalty = abs(premium ?: 0.0) > 2.5
        val aligned = if (expectedReturn >= 0.0) !premiumPenalty else true
        val action = when {
            expectedReturn >= 0.45 && probability >= 60.0 && aligned -> GoldAction.BUY
            expectedReturn <= -0.45 && probability >= 60.0 -> GoldAction.SELL
            else -> GoldAction.WAIT
        }
        val confidence = when {
            probability >= 70.0 && bars.size >= 120 -> GoldConfidence.HIGH
            probability >= 60.0 -> GoldConfidence.MEDIUM
            else -> GoldConfidence.LOW
        }
        val entryFrom = if (action == GoldAction.WAIT) null else input.nowEpochMs + 15 * 60_000L
        val entryUntil = if (action == GoldAction.WAIT) null else input.nowEpochMs + 60 * 60_000L
        val exitFrom = if (action == GoldAction.WAIT) null else input.nowEpochMs + horizonBars * 60 * 60_000L
        val exitUntil = if (action == GoldAction.WAIT) null else input.nowEpochMs + (horizonBars + 2) * 60 * 60_000L
        val current = input.domestic18kPerGram
        val stop = when (action) {
            GoldAction.BUY -> current * (1.0 - stopDistance)
            GoldAction.SELL -> current * (1.0 + stopDistance)
            else -> null
        }
        val target = when (action) {
            GoldAction.BUY -> current * (1.0 + targetDistance)
            GoldAction.SELL -> current * (1.0 - targetDistance)
            else -> null
        }
        return GoldAnalysisOutput(
            action, confidence, theoretical, mesghalDerived, premium, coinPremium, expectedReturn,
            probability, targetDistance * 100.0, stopDistance * 100.0,
            entryFrom, entryUntil, exitFrom, exitUntil, stop, target,
            when (action) {
                GoldAction.BUY -> "روند و ارزیابی تاریخی از سناریوی صعودی پشتیبانی می‌کنند؛ ورود فقط در بازه اعلام‌شده و با رعایت حد ضرر معتبر است."
                GoldAction.SELL -> "روند و ارزیابی تاریخی از سناریوی نزولی پشتیبانی می‌کنند؛ خروج باید با رعایت حد ریسک انجام شود."
                else -> "شواهد برای ورود یا خروج کافی نیست؛ حفظ سرمایه و انتظار منطقی‌تر است."
            }
        )
    }
}
