package com.hamrahsarmaye.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** One provider endpoint. Credentials must live on the maker's HTTPS backend, never in this object. */
data class GlobalFeedSource(
    val providerName: String,
    val endpoint: String,
    val valuePath: String,
    val timestampPath: String,
    val currency: String,
    val unit: String,
    val marketName: String,
    val status: QuoteStatus = QuoteStatus.LIVE,
    val comparableToPrimary: Boolean = false
) {
    fun toJson() = JSONObject().apply {
        put("providerName", providerName); put("endpoint", endpoint); put("valuePath", valuePath)
        put("timestampPath", timestampPath); put("currency", currency); put("unit", unit)
        put("marketName", marketName); put("status", status.name); put("comparableToPrimary", comparableToPrimary)
    }

    companion object {
        fun fromJson(o: JSONObject) = GlobalFeedSource(
            o.optString("providerName"), o.optString("endpoint"), o.optString("valuePath"),
            o.optString("timestampPath"), o.optString("currency", "USD"),
            o.optString("unit"), o.optString("marketName"),
            runCatching { QuoteStatus.valueOf(o.optString("status", "LIVE")) }.getOrDefault(QuoteStatus.UNAVAILABLE),
            o.optString("comparableToPrimary", "false").toBoolean()
        )
    }
}

data class GlobalAssetReference(
    val assetKey: String,
    val benchmarkId: String,
    val displayName: String,
    val providerName: String = "",
    val endpoint: String = "",
    val valuePath: String = "",
    val timestampPath: String = "",
    val currency: String = "USD",
    val unit: String = "",
    val status: String,
    val primaryMarket: String = "",
    val alternativeMarkets: List<String> = emptyList(),
    val fallbackSources: List<GlobalFeedSource> = emptyList(),
    val providerStatus: QuoteStatus = QuoteStatus.LIVE,
    val resolvedAtEpochMs: Long = System.currentTimeMillis()
) {
    val feedReady: Boolean
        get() = endpoint.startsWith("https://", true) && providerName.isNotBlank() &&
            valuePath.isNotBlank() && timestampPath.isNotBlank() && unit.isNotBlank()

    fun toJson() = JSONObject().apply {
        put("assetKey", assetKey); put("benchmarkId", benchmarkId); put("displayName", displayName)
        put("providerName", providerName); put("endpoint", endpoint); put("valuePath", valuePath)
        put("timestampPath", timestampPath); put("currency", currency); put("unit", unit)
        put("status", status); put("primaryMarket", primaryMarket)
        put("alternativeMarkets", JSONArray(alternativeMarkets))
        put("fallbackSources", JSONArray().apply { fallbackSources.forEach { put(it.toJson()) } })
        put("providerStatus", providerStatus.name)
        put("resolvedAtEpochMs", resolvedAtEpochMs)
    }

    companion object {
        fun fromJson(o: JSONObject): GlobalAssetReference {
            val alternatives = o.optJSONArray("alternativeMarkets") ?: JSONArray()
            val fallbacks = o.optJSONArray("fallbackSources") ?: JSONArray()
            return GlobalAssetReference(
                assetKey = o.optString("assetKey"), benchmarkId = o.optString("benchmarkId"),
                displayName = o.optString("displayName"), providerName = o.optString("providerName"),
                endpoint = o.optString("endpoint"), valuePath = o.optString("valuePath"),
                timestampPath = o.optString("timestampPath"), currency = o.optString("currency", "USD"),
                unit = o.optString("unit"), status = o.optString("status"),
                primaryMarket = o.optString("primaryMarket"),
                alternativeMarkets = (0 until alternatives.length()).mapNotNull { alternatives.optString(it).takeIf(String::isNotBlank) },
                fallbackSources = (0 until fallbacks.length()).mapNotNull { fallbacks.optJSONObject(it)?.let(GlobalFeedSource::fromJson) },
                providerStatus = runCatching { QuoteStatus.valueOf(o.optString("providerStatus", "LIVE")) }.getOrDefault(QuoteStatus.UNAVAILABLE),
                resolvedAtEpochMs = o.optLong("resolvedAtEpochMs", 0L)
            )
        }
    }
}

object GlobalAssetResolver {
    /** Maker-controlled HTTPS registry. Blank until a real provider backend has been deployed. */
    private val registryUrl: String get() = BuildConfig.GLOBAL_ASSET_REGISTRY_URL
    private const val CONNECT_TIMEOUT_MS = 8_000
    private const val READ_TIMEOUT_MS = 8_000
    private const val MAX_REGISTRY_BYTES = 512_000
    private const val REGISTRY_CACHE_MS = 5 * 60_000L
    @Volatile private var cachedRegistry: JSONObject? = null
    @Volatile private var registryCacheUntilMs: Long = 0L

    data class Candidate(
        val key: String,
        val benchmark: String,
        val label: String,
        val defaultUnit: String,
        val primaryMarket: String,
        val alternativeMarkets: List<String> = emptyList(),
        val currency: String = "USD"
    )

    /**
     * Resolve only unambiguous instruments. A currency by itself is not a tradable FX pair;
     * USD/DXY is an index and must never be mistaken for the local cash dollar price.
     */
    fun identify(assetType: String, assetName: String): Candidate? {
        val n = assetName.lowercase(Locale.ROOT)
        val t = assetType.lowercase(Locale.ROOT)
        return when {
            listOf("پالادیوم", "palladium").any(n::contains) -> Candidate("palladium.spot", "XPDUSD", "Palladium spot", "troy_ounce", "LBMA / ICE Benchmark Administration (London)", listOf("NYMEX / CME Group (New York)"))
            listOf("پلاتین", "platinum").any(n::contains) -> Candidate("platinum.spot", "XPTUSD", "Platinum spot", "troy_ounce", "LBMA / ICE Benchmark Administration (London)", listOf("NYMEX / CME Group (New York)"))
            ("طلا" in n || "gold" in n || "gold" in t || "سکه" in n || "شمش طلا" in n) -> Candidate("gold.spot", "XAUUSD", "Gold spot", "troy_ounce", "LBMA Gold Price / ICE Benchmark Administration (London)", listOf("COMEX Gold Futures / CME Group (New York)"))
            ("نقره" in n || "silver" in n || "silver" in t) -> Candidate("silver.spot", "XAGUSD", "Silver spot", "troy_ounce", "LBMA Silver Price / ICE Benchmark Administration (London)", listOf("COMEX Silver Futures / CME Group (New York)"))
            listOf("مس", "copper").any(n::contains) -> Candidate("metal.copper", "LME_CU", "Copper", "metric_tonne", "London Metal Exchange (LME)", listOf("COMEX / CME Group"))
            listOf("آلومینیوم", "aluminium", "aluminum").any(n::contains) -> Candidate("metal.aluminium", "LME_AL", "Aluminium", "metric_tonne", "London Metal Exchange (LME)")
            listOf("نیکل", "nickel").any(n::contains) -> Candidate("metal.nickel", "LME_NI", "Nickel", "metric_tonne", "London Metal Exchange (LME)")
            listOf("روی", "zinc").any(n::contains) -> Candidate("metal.zinc", "LME_ZN", "Zinc", "metric_tonne", "London Metal Exchange (LME)")
            listOf("سرب", "lead").any(n::contains) -> Candidate("metal.lead", "LME_PB", "Lead", "metric_tonne", "London Metal Exchange (LME)")
            listOf("قلع", "tin").any(n::contains) -> Candidate("metal.tin", "LME_SN", "Tin", "metric_tonne", "London Metal Exchange (LME)")
            listOf("شاخص دلار", "dxy", "dollar index").any(n::contains) -> Candidate("fx.dxy", "DXY", "US Dollar Index", "index_points", "ICE U.S. Dollar Index Futures (New York)")
            listOf("یورو", "eurusd", "eur/usd", "euro/usd").any(n::contains) -> Candidate("fx.eurusd", "EURUSD", "EUR/USD", "currency_pair", "Global OTC FX market", listOf("CME Euro FX Futures (Chicago)"))
            listOf("پوند", "gbpusd", "gbp/usd").any(n::contains) -> Candidate("fx.gbpusd", "GBPUSD", "GBP/USD", "currency_pair", "Global OTC FX market", listOf("CME British Pound Futures (Chicago)"))
            listOf("ین ژاپن", "usdjpy", "usd/jpy").any(n::contains) -> Candidate("fx.usdjpy", "USDJPY", "USD/JPY", "currency_pair", "Global OTC FX market", listOf("CME Japanese Yen Futures (Chicago)"))
            listOf("فرانک سوئیس", "usdchf", "usd/chf").any(n::contains) -> Candidate("fx.usdchf", "USDCHF", "USD/CHF", "currency_pair", "Global OTC FX market")
            listOf("دلار استرالیا", "audusd", "aud/usd").any(n::contains) -> Candidate("fx.audusd", "AUDUSD", "AUD/USD", "currency_pair", "Global OTC FX market")
            listOf("دلار کانادا", "usdcad", "usd/cad").any(n::contains) -> Candidate("fx.usdcad", "USDCAD", "USD/CAD", "currency_pair", "Global OTC FX market")
            listOf("نفت برنت", "brent").any(n::contains) -> Candidate("energy.brent", "BRENT", "Brent crude", "barrel", "ICE Futures Europe (London)")
            listOf("نفت wti", "wti").any(n::contains) -> Candidate("energy.wti", "WTI", "WTI crude", "barrel", "NYMEX / CME Group (New York)")
            listOf("گاز طبیعی", "natural gas", "henry hub").any(n::contains) -> Candidate("energy.natgas", "NATGAS", "Henry Hub Natural Gas", "mmbtu", "NYMEX / CME Group (New York)")
            listOf("بیت کوین", "bitcoin", "btc/usd", "btcusd").any(n::contains) -> Candidate("crypto.btcusd", "BTCUSD", "Bitcoin/USD", "coin", "Aggregated spot crypto venues")
            listOf("اتریوم", "ethereum", "eth/usd", "ethusd").any(n::contains) -> Candidate("crypto.ethusd", "ETHUSD", "Ethereum/USD", "coin", "Aggregated spot crypto venues")
            listOf("s&p 500", "sp500", "spx", "اس اند پی ۵۰۰", "شاخص اس اند پی").any(n::contains) -> Candidate("index.sp500", "SPX", "S&P 500", "index_points", "S&P Dow Jones Indices (United States)", listOf("CME E-mini S&P 500 Futures (Chicago)"))
            listOf("nasdaq 100", "nasdaq100", "ndx", "نزدک ۱۰۰").any(n::contains) -> Candidate("index.nasdaq100", "NDX", "Nasdaq-100", "index_points", "Nasdaq (United States)", listOf("CME E-mini Nasdaq-100 Futures (Chicago)"))
            listOf("ftse 100", "ftse100", "شاخص فوتسی").any(n::contains) -> Candidate("index.ftse100", "UKX", "FTSE 100", "index_points", "FTSE Russell (United Kingdom)", listOf("ICE Futures Europe (London)"))
            listOf("dax", "dax 40", "شاخص دکس").any(n::contains) -> Candidate("index.dax", "DAX", "DAX 40", "index_points", "Deutsche Börse (Germany)", listOf("Eurex (Germany)"))
            listOf("nikkei 225", "nikkei225", "نیکی ۲۲۵").any(n::contains) -> Candidate("index.nikkei225", "N225", "Nikkei 225", "index_points", "Japan Exchange Group / Osaka Exchange", listOf("CME Nikkei 225 Futures"))
            listOf("hang seng", "hsi", "هنگ سنگ").any(n::contains) -> Candidate("index.hsi", "HSI", "Hang Seng Index", "index_points", "Hong Kong Exchanges and Clearing (HKEX)")
            listOf("shanghai composite", "sse composite", "شاخص شانگهای").any(n::contains) -> Candidate("index.sse", "SSECOMP", "Shanghai Composite", "index_points", "Shanghai Stock Exchange (China)")
            // A plain USD, EUR, car or property name does not identify a global tradable benchmark.
            else -> null
        }
    }

    fun resolve(assetType: String, assetName: String): GlobalAssetReference? {
        val c = identify(assetType, assetName) ?: return null
        val base = GlobalAssetReference(
            assetKey = c.key, benchmarkId = c.benchmark, displayName = c.label,
            currency = c.currency, unit = c.defaultUnit,
            primaryMarket = c.primaryMarket, alternativeMarkets = c.alternativeMarkets,
            status = "بازار مرجع شناسایی شد: ${c.primaryMarket}؛ اتصال قیمت نیازمند تأمین‌کننده مجاز و تنظیم‌شده است"
        )
        if (registryUrl.isBlank()) return base
        val registry = fetchRegistry() ?: return base.copy(status = "بازار مرجع شناسایی شد؛ فهرست امن منابع در دسترس نیست")
        val entries = registry.optJSONArray("assets") ?: return base
        for (i in 0 until entries.length()) {
            val o = entries.optJSONObject(i) ?: continue
            if (!o.optString("assetKey").equals(c.key, true)) continue
            if (!o.optString("benchmarkId").equals(c.benchmark, true)) return base
            val primary = parseSource(o, c.primaryMarket, c.defaultUnit, c.currency) ?: return base
            val fallbackArray = o.optJSONArray("fallbacks") ?: JSONArray()
            val fallbacks = (0 until fallbackArray.length()).mapNotNull { i ->
                fallbackArray.optJSONObject(i)?.let { parseSource(it, "Alternative provider", c.defaultUnit, c.currency) }
            }.filter { it.comparableToPrimary && it.currency.equals(primary.currency, true) && it.unit.equals(primary.unit, true) }
            return base.copy(
                providerName = primary.providerName, endpoint = primary.endpoint,
                valuePath = primary.valuePath, timestampPath = primary.timestampPath,
                currency = primary.currency, unit = primary.unit,
                primaryMarket = primary.marketName,
                providerStatus = primary.status,
                fallbackSources = fallbacks,
                status = "بازار مرجع: ${primary.marketName}؛ ${1 + fallbacks.size} مسیر تأمین داده از فهرست سازنده دریافت شد"
            )
        }
        return base
    }

    private fun parseSource(o: JSONObject, defaultMarket: String, defaultUnit: String, defaultCurrency: String): GlobalFeedSource? {
        val endpoint = o.optString("endpoint")
        val provider = o.optString("providerName")
        val valuePath = o.optString("valuePath")
        val timestampPath = o.optString("timestampPath")
        val currency = o.optString("currency", defaultCurrency)
        val unit = o.optString("unit", defaultUnit)
        val marketName = o.optString("marketName", defaultMarket)
        if (!endpoint.startsWith("https://", true) || provider.isBlank() || valuePath.isBlank() ||
            timestampPath.isBlank() || currency.isBlank() || unit.isBlank()) return null
        val status = runCatching { QuoteStatus.valueOf(o.optString("status", "LIVE")) }.getOrDefault(QuoteStatus.UNAVAILABLE)
        val comparable = o.optString("comparableToPrimary", "false").toBoolean()
        return GlobalFeedSource(provider, endpoint, valuePath, timestampPath, currency, unit, marketName, status, comparable)
    }

    private fun fetchRegistry(): JSONObject? {
        if (!registryUrl.startsWith("https://", true)) return null
        val now = System.currentTimeMillis()
        if (now < registryCacheUntilMs) return cachedRegistry
        synchronized(this) {
            if (System.currentTimeMillis() < registryCacheUntilMs) return cachedRegistry
            var conn: HttpURLConnection? = null
            val result = try {
                conn = (URL(registryUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = CONNECT_TIMEOUT_MS; readTimeout = READ_TIMEOUT_MS
                    setRequestProperty("Accept", "application/json")
                }
                if (conn.url.protocol != "https" || conn.responseCode !in 200..299) null else {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if (body.toByteArray(Charsets.UTF_8).size > MAX_REGISTRY_BYTES) null else JSONObject(body)
                }
            } catch (_: Exception) { null } finally { conn?.disconnect() }
            cachedRegistry = result
            // Short negative cache prevents ten catalogue entries from hammering an unavailable registry.
            registryCacheUntilMs = System.currentTimeMillis() + if (result == null) 30_000L else REGISTRY_CACHE_MS
            return result
        }
    }

    fun save(prefs: SharedPreferences, reference: GlobalAssetReference) {
        prefs.edit().putString("global_ref_${reference.assetKey}", reference.toJson().toString()).apply()
    }

    fun load(prefs: SharedPreferences, assetType: String, assetName: String): GlobalAssetReference? {
        val candidate = identify(assetType, assetName) ?: return null
        val raw = prefs.getString("global_ref_${candidate.key}", null) ?: return null
        return try {
            val saved = GlobalAssetReference.fromJson(JSONObject(raw))
            if (saved.primaryMarket.isBlank()) saved.copy(
                primaryMarket = candidate.primaryMarket,
                alternativeMarkets = candidate.alternativeMarkets
            ) else saved
        } catch (_: Exception) { null }
    }

    fun toFeedConfig(reference: GlobalAssetReference): MarketFeedConfig? {
        if (!reference.feedReady) return null
        return MarketFeedConfig(
            id = "global_${reference.assetKey}", endpoint = reference.endpoint,
            valuePath = reference.valuePath, timestampPath = reference.timestampPath,
            currency = reference.currency, unit = reference.unit, providerName = reference.providerName,
            assetKey = reference.assetKey, market = QuoteMarket.GLOBAL,
            marketName = reference.primaryMarket,
            providerStatus = reference.providerStatus,
            fallbacks = reference.fallbackSources
        )
    }
}
