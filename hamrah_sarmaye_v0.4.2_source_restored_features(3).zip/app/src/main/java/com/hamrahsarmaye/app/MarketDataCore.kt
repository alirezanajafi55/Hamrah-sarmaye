package com.hamrahsarmaye.app

/** Quotes are provider-sourced records. MANUAL is retained only for legacy/imported records. */
enum class QuoteStatus { LIVE, DELAYED, STALE, UNAVAILABLE, MANUAL }
enum class QuoteMarket { DOMESTIC, GLOBAL }

data class MarketQuote(
    val value: Double,
    val currency: String,
    val unit: String,
    val provider: String,
    val observedAtEpochMs: Long,
    val receivedAtEpochMs: Long,
    val status: QuoteStatus,
    val market: QuoteMarket,
    val countryCode: String? = null,
    val assetKey: String,
    val marketName: String = ""
)

data class QuoteDecision(val usableForAnalysis: Boolean, val displayStatus: QuoteStatus, val reason: String)

object MarketDataPolicy {
    /** Never promotes an old/manual/invalid quote to live. */
    fun assess(q: MarketQuote?, nowMs: Long = System.currentTimeMillis(), maxLiveAgeMs: Long = 5 * 60_000L): QuoteDecision {
        if (q == null) return QuoteDecision(false, QuoteStatus.UNAVAILABLE, "No provider quote")
        if (!q.value.isFinite() || q.value <= 0.0 || q.currency.isBlank() || q.unit.isBlank() || q.provider.isBlank())
            return QuoteDecision(false, QuoteStatus.UNAVAILABLE, "Invalid quote fields")
        if (q.observedAtEpochMs <= 0L || q.observedAtEpochMs > nowMs || q.receivedAtEpochMs > nowMs)
            return QuoteDecision(false, QuoteStatus.UNAVAILABLE, "Invalid quote timestamp")
        if (q.status == QuoteStatus.MANUAL || q.status == QuoteStatus.UNAVAILABLE)
            return QuoteDecision(false, q.status, "Manual or unavailable quote cannot drive signals")
        val age = nowMs - q.observedAtEpochMs
        if (age > maxLiveAgeMs) return QuoteDecision(false, QuoteStatus.STALE, "Quote is stale")
        if (q.status == QuoteStatus.STALE) return QuoteDecision(false, QuoteStatus.STALE, "Provider marked quote stale")
        return QuoteDecision(true, q.status, "Quote passed basic freshness checks")
    }

    /** Domestic provider selection changes with country; global reference key is asset-specific. */
    fun domesticQuoteMatches(q: MarketQuote, selectedCountryCode: String) =
        q.market == QuoteMarket.DOMESTIC && q.countryCode.equals(selectedCountryCode, ignoreCase = true)

    fun globalQuoteMatches(q: MarketQuote, assetKey: String) =
        q.market == QuoteMarket.GLOBAL && q.assetKey.equals(assetKey, ignoreCase = true)
}

object GoldMath {
    const val GOLD_18_FACTOR = 41.4713
    fun theoretical18kGram(spotUsdPerTroyOunce: Double, domesticUsdRate: Double): Double? {
        if (!spotUsdPerTroyOunce.isFinite() || !domesticUsdRate.isFinite() || spotUsdPerTroyOunce <= 0 || domesticUsdRate <= 0) return null
        val result = spotUsdPerTroyOunce * domesticUsdRate / GOLD_18_FACTOR
        return result.takeIf { it.isFinite() && it > 0 }
    }
    fun rawBubblePercent(domestic18kGramPrice: Double, theoretical18kGramPrice: Double): Double? {
        if (!domestic18kGramPrice.isFinite() || !theoretical18kGramPrice.isFinite() || domestic18kGramPrice <= 0 || theoretical18kGramPrice <= 0) return null
        val result = (domestic18kGramPrice - theoretical18kGramPrice) / theoretical18kGramPrice * 100.0
        return result.takeIf { it.isFinite() }
    }
}

/** Fixed global benchmark identifiers; domestic country selection must never rewrite these references. */
object GlobalBenchmarkCatalog {
    /** Keep legacy callers aligned with the same strict market resolver. */
    fun benchmarkFor(assetType: String, assetName: String): String? =
        GlobalAssetResolver.identify(assetType, assetName)?.benchmark
}
