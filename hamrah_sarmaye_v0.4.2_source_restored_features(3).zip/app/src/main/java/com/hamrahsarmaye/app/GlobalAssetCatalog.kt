package com.hamrahsarmaye.app

/** Maker-owned market catalogue. A reference describes the correct benchmark, not a live quote. */
data class GlobalCatalogEntry(
    val key: String,
    val title: String,
    val assetType: String,
    val assetName: String,
    val benchmarkId: String,
    val unit: String,
    val description: String,
    val primaryMarket: String = "",
    val alternativeMarkets: List<String> = emptyList(),
    val quoteKind: String = "SPOT"
)

data class AssetCategory(
    val key: String,
    val title: String,
    val icon: String,
    val assetType: String,
    val description: String
)

object GlobalAssetCatalog {
    /** Stable category identities/icons; users select groups, not arbitrary replacement artwork. */
    val categories = listOf(
        AssetCategory("gold", "طلا", "🥇", "طلا و فلزات", "طلای ۱۸ عیار، آب‌شده، مثقال، سکه و اونس"),
        AssetCategory("silver", "نقره", "🪙", "طلا و فلزات", "نقره با عیار و وزن مشخص"),
        AssetCategory("fx", "ارز", "💱", "ارز", "دلار، یورو و ارزهای قابل انتخاب"),
        AssetCategory("vehicle", "خودرو", "🚗", "خودرو", "انتخاب آزاد سازنده، مدل، تیپ، سال و کارکرد"),
        AssetCategory("property", "ملک", "🏠", "خانه / ملک", "انتخاب نوع ملک، کشور، شهر، منطقه و مشخصات"),
        AssetCategory("energy", "نفت و کالا", "🛢️", "نفت و کالا", "نفت و کالاهای منتخب با مرجع تخصصی")
    )

    /**
     * Exchange/benchmark map. London/NY market names are references only: live data is enabled
     * only after the maker installs a licensed provider endpoint in the secure registry.
     */
    val globalReferences = listOf(
        GlobalCatalogEntry("gold.spot", "اونس جهانی طلا", "طلا و فلزات", "اونس جهانی طلا", "XAUUSD", "troy_ounce",
            "قیمت نقدی جهانی طلا به دلار برای هر اونس تروا؛ بازار اصلی: LBMA/ICE لندن؛ مرجع جایگزین مقایسه‌ای: COMEX/CME نیویورک (قرارداد آتی، نه قیمت نقدی)", "LBMA Gold Price / ICE Benchmark Administration (London)",
            listOf("COMEX Gold Futures / CME Group (New York)")),
        GlobalCatalogEntry("silver.spot", "اونس جهانی نقره", "طلا و فلزات", "اونس جهانی نقره", "XAGUSD", "troy_ounce",
            "قیمت جهانی نقره به دلار برای هر اونس تروا؛ بازار اصلی: LBMA/ICE لندن؛ مرجع جایگزین مقایسه‌ای: COMEX/CME نیویورک (قرارداد آتی، نه قیمت نقدی)", "LBMA Silver Price / ICE Benchmark Administration (London)",
            listOf("COMEX Silver Futures / CME Group (New York)")),
        GlobalCatalogEntry("fx.eurusd", "جفت‌ارز EUR/USD", "ارز", "EUR/USD", "EURUSD", "currency_pair",
            "نرخ مرجع جهانی یورو در برابر دلار؛ بازار اصلی: بازار بین‌بانکی جهانی OTC؛ مرجع آتی جایگزین: CME شیکاگو", "Global OTC FX market",
            listOf("CME Euro FX Futures (Chicago)")),
        GlobalCatalogEntry("fx.gbpusd", "جفت‌ارز GBP/USD", "ارز", "GBP/USD", "GBPUSD", "currency_pair",
            "نرخ مرجع جهانی پوند در برابر دلار؛ بازار اصلی: بازار بین‌بانکی جهانی OTC؛ مرجع آتی جایگزین: CME شیکاگو", "Global OTC FX market",
            listOf("CME British Pound Futures (Chicago)")),
        GlobalCatalogEntry("fx.usdjpy", "جفت‌ارز USD/JPY", "ارز", "USD/JPY", "USDJPY", "currency_pair",
            "نرخ مرجع جهانی دلار در برابر ین؛ بازار اصلی: بازار بین‌بانکی جهانی OTC؛ مرجع آتی جایگزین: CME شیکاگو", "Global OTC FX market",
            listOf("CME Japanese Yen Futures (Chicago)")),
        GlobalCatalogEntry("fx.dxy", "شاخص جهانی دلار", "ارز", "شاخص دلار", "DXY", "index_points",
            "شاخص وزنی دلار آمریکا در برابر سبد ارزها؛ بازار اصلی: ICE نیویورک؛ این شاخص معادل قیمت دلار نقدی داخلی نیست", "ICE U.S. Dollar Index Futures (New York)"),
        GlobalCatalogEntry("energy.brent", "نفت برنت", "نفت و کالا", "نفت برنت", "BRENT", "barrel",
            "شاخص جهانی نفت برنت به دلار برای هر بشکه؛ بازار اصلی: ICE Futures Europe لندن", "ICE Futures Europe (London)"),
        GlobalCatalogEntry("energy.wti", "نفت WTI", "نفت و کالا", "نفت WTI", "WTI", "barrel",
            "شاخص جهانی نفت WTI به دلار برای هر بشکه؛ بازار اصلی: NYMEX/CME نیویورک", "NYMEX / CME Group (New York)"),
        GlobalCatalogEntry("metal.copper", "مس جهانی", "فلزات صنعتی", "مس", "LME_CU", "metric_tonne",
            "قیمت مرجع مس صنعتی؛ بازار اصلی: London Metal Exchange (LME)؛ قرارداد آتی جایگزین: COMEX/CME", "London Metal Exchange (LME)", listOf("COMEX Copper Futures / CME Group")),
        GlobalCatalogEntry("index.sp500", "شاخص S&P 500", "شاخص سهام", "S&P 500", "SPX", "index_points",
            "شاخص سهام بزرگ آمریکا؛ مرجع شاخص: S&P Dow Jones Indices؛ قرارداد آتی جداگانه: CME E-mini در شیکاگو", "S&P Dow Jones Indices (United States)",
            listOf("CME E-mini S&P 500 Futures (Chicago)"))
    )

    fun referenceByKey(key: String): GlobalCatalogEntry? = globalReferences.firstOrNull { it.key == key }
}
