package com.hamrahsarmaye.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GlobalAssetResolverTest {
    @Test fun goldAndSilverResolveToLondonBenchmarks() {
        assertEquals("gold.spot", GlobalAssetResolver.identify("طلا و فلزات", "طلای ۱۸ عیار")?.key)
        assertEquals("gold.spot", GlobalAssetResolver.identify("طلا و فلزات", "سکه امامی")?.key)
        assertEquals("silver.spot", GlobalAssetResolver.identify("طلا و فلزات", "نقره ۹۲۵")?.key)
    }

    @Test fun currenciesResolveToPairsNotDomesticCashQuotes() {
        assertEquals("fx.eurusd", GlobalAssetResolver.identify("ارز", "یورو")?.key)
        assertEquals("fx.dxy", GlobalAssetResolver.identify("ارز", "شاخص دلار")?.key)
        assertNull(GlobalAssetResolver.identify("ارز", "دلار آزاد"))
    }

    @Test fun energyAndIndustrialBenchmarksResolve() {
        assertEquals("energy.brent", GlobalAssetResolver.identify("نفت و کالا", "نفت برنت")?.key)
        assertEquals("energy.wti", GlobalAssetResolver.identify("نفت و کالا", "نفت WTI")?.key)
        assertEquals("metal.copper", GlobalAssetResolver.identify("فلزات صنعتی", "مس")?.key)
    }

    @Test fun majorStockIndicesResolveWithoutGuessingIndividualShares() {
        assertEquals("index.sp500", GlobalAssetResolver.identify("شاخص سهام", "S&P 500")?.key)
        assertEquals("index.nikkei225", GlobalAssetResolver.identify("شاخص سهام", "Nikkei 225")?.key)
        assertNull(GlobalAssetResolver.identify("خودرو", "Toyota Camry"))
        assertNull(GlobalAssetResolver.identify("خانه / ملک", "Apartment in Tehran"))
    }

    @Test fun initialGlobalReferenceSetIsTenItems() {
        assertEquals(10, GlobalAssetCatalog.globalReferences.size)
        assertTrue(GlobalAssetCatalog.globalReferences.any { it.key == "gold.spot" })
        assertTrue(GlobalAssetCatalog.globalReferences.any { it.key == "index.sp500" })
    }
}
