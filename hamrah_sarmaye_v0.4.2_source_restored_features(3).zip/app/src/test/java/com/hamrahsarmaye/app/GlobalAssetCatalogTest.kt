package com.hamrahsarmaye.app

import org.junit.Assert.*
import org.junit.Test

class GlobalAssetCatalogTest {
    @Test fun vehicleAndPropertyAreSelectableCategoriesNotFixedModels() {
        assertTrue(GlobalAssetCatalog.categories.any { it.key == "vehicle" && it.assetType == "خودرو" })
        assertTrue(GlobalAssetCatalog.categories.any { it.key == "property" && it.assetType == "خانه / ملک" })
        assertFalse(GlobalAssetCatalog.categories.any { it.title.contains("Toyota") || it.title.contains("تویوتا") })
    }

    @Test fun globalReferencesExistWithoutUserHoldings() {
        assertTrue(GlobalAssetCatalog.globalReferences.any { it.key == "gold.spot" })
        assertTrue(GlobalAssetCatalog.globalReferences.any { it.key == "silver.spot" })
        assertTrue(GlobalAssetCatalog.globalReferences.any { it.key == "fx.eurusd" })
        assertTrue(GlobalAssetCatalog.globalReferences.none { it.assetType == "خودرو" || it.assetType == "خانه / ملک" })
    }

    @Test fun noUniversalGlobalQuoteIsInventedForCarsOrProperty() {
        assertEquals(null, GlobalBenchmarkCatalog.benchmarkFor("خودرو", "تویوتا کرولا"))
        assertEquals(null, GlobalBenchmarkCatalog.benchmarkFor("خانه / ملک", "آپارتمان تهران"))
    }
}
