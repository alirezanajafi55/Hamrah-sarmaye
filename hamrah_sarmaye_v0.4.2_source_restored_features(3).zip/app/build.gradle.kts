plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val globalAssetRegistryUrl = providers.gradleProperty("GLOBAL_ASSET_REGISTRY_URL").orElse("").get()
val releaseStoreFile = providers.environmentVariable("ANDROID_RELEASE_STORE_FILE").orNull
val releaseStorePassword = providers.environmentVariable("ANDROID_RELEASE_STORE_PASSWORD").orNull
val releaseKeyAlias = providers.environmentVariable("ANDROID_RELEASE_KEY_ALIAS").orNull
val releaseKeyPassword = providers.environmentVariable("ANDROID_RELEASE_KEY_PASSWORD").orNull
val releaseSigningReady = listOf(
    releaseStoreFile,
    releaseStorePassword,
    releaseKeyAlias,
    releaseKeyPassword
).all { !it.isNullOrBlank() }

android {
    namespace = "com.hamrahsarmaye.app"
    compileSdk = 35

    buildFeatures { buildConfig = true }
    defaultConfig {
        buildConfigField("String", "GLOBAL_ASSET_REGISTRY_URL", "\"${globalAssetRegistryUrl}\"")
        applicationId = "com.hamrahsarmaye.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 18
        versionName = "0.4.2-dev"
    }

    if (releaseSigningReady) {
        signingConfigs {
            create("release") {
                storeFile = file(requireNotNull(releaseStoreFile))
                storePassword = requireNotNull(releaseStorePassword)
                keyAlias = requireNotNull(releaseKeyAlias)
                keyPassword = requireNotNull(releaseKeyPassword)
            }
        }
    }

    buildTypes {
        getByName("release") {
            if (releaseSigningReady) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
