# وضعیت ساخت نسخه ۰.۴.۲-dev

- Package ID: `com.hamrahsarmaye.app`
- Version name: `0.4.2-dev`
- Version code: `18`
- Compile SDK: `35`
- Java: `17`
- Android Gradle Plugin: `8.7.3`
- Gradle: `8.9`
- Debug build: منتظر اجرای GitHub Actions
- Release build: فقط در صورت تنظیم چهار GitHub Actions Secret امضا ساخته می‌شود.
- نصب روی دستگاه: هنوز آزمایش نشده است.
- به‌روزرسانی روی نسخه نصب‌شده: تا زمان بررسی اثر انگشت امضا تأیید نشده است.
